# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '53483f7b2891b77606175093175778442089020eb5dd6c1c7bfb89b5e4f98436900dbac606d753b8b7de6358800f1976923f9df873049ae882464cdfc5b78c88'
